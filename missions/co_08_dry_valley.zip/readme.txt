The .pbo file is a fully playable mission file. The folder contains the mission creation data for the mission editor.

co 08 dry valley.Malden.pbo goes into your mpmissions folder, e.g. ...\Steam\steamapps\common\Arma 3\MPMissions.
co 08 dry valley folder goes into your editor missions folder, e.g. C:\Users\(your name)\Documents\Arma 3 - Other Profiles\(your nickname)\mpmissions

License: MIT